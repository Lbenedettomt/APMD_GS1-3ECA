package main;

public enum plugs {
	
		tipo1,
		tipo2,
		css2,
		chademo
}
